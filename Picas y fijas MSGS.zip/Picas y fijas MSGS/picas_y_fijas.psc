Algoritmo picas_y_fijas
	Dimension clave[4] 
	Dimension intento[4]
	Dimension numerosFijas[4]
	Dimension numerosPicas[4]
	
	Definir  i, j, num Como Entero
	Definir repetido Como Logico
	
	Para i <- 1 Hasta 4 Con Paso 1 Hacer
		Repetir
			repetido <- Falso
			Si i = 1 Entonces
				num <- Aleatorio(1,9) // el primer digito no ebe ser 0
			Sino 
				num <- Aleatorio(0,9)
			FinSi
			Para j <- 1 Hasta i-1 Con Paso 1 Hacer
				Si num = clave[j] Entonces
					repetido <- Verdadero
				FinSi
			FinPara
		Hasta Que repetido = Falso
		
		clave[i] <- num
	FinPara
	
	Mientras fijas <> 4 y intentos < 12 Hacer
		intentos <- intentos + 1
		fijas <- 0
		picas <- 0
		Escribir ""
		Escribir "intento ", intentos, " de 12"
	Escribir ""
	Escribir "Ingresa tu numero de 4 cifras: "
	
	Para i <- 1 Hasta 4 Con Paso 1 Hacer
		Escribir "Digito ", i , ": " Sin Saltar
		Leer intento[i]
	FinPara
	
	Escribir ""
	Escribir "Tu intento fue: ", intento[1], intento[2], intento[3], intento[4]
	
	Para i <- 1 Hasta 4 Con Paso 1 Hacer
		numerosFijas[i] <- -1
		numerosPicas[i] <- -1
	FinPara
	
	Para i <- 1 Hasta 4 Con Paso 1 Hacer
		Si intento[i] = clave[i] Entonces
			fijas <- fijas +1
			numerosFijas[fijas] <- intento[i]
		Sino
			Para j <- 1 Hasta 4 Con Paso 1 Hacer
				Si intento[i] = clave[j] Entonces
					picas <- picas +1
					numerosPicas[picas] <- intento[i]	
				FinSi
			FinPara
		FinSi
    FinPara
	
	Escribir ""
	Escribir "Fijas: ", fijas, " (numeros: " Sin Saltar
	Para i <- 1 Hasta fijas Con Paso 1 Hacer
		Escribir numerosFijas[i], " " Sin Saltar
	FinPara
	Escribir ")"
	
	Escribir "Picas: ", picas, " (numeros: " Sin Saltar
	Para i <- 1 Hasta picas Con Paso 1 Hacer
		Escribir numerosPicas[i], " " Sin Saltar
	FinPara
	
FinMientras
Escribir ""
Si fijas = 4 Entonces
	Escribir " Ganaste"
	Si intentos < 2 Entonces
		Escribir "Excelente, eres un maestro estas fuera del alcance de los dem�s"
	    SiNo
		    Si intentos < 4 Entonces
		        Escribir "Muy bueno, puedes ser un gran competidor"
			SiNo
				Si intentos < 8 Entonces
		            Escribir "Bien, estas progresando debes buscar tus l�mites"	
				SiNo
		            Si intentos < 10 Entonces
						Escribir "Regular, a�n es largo el camino por recorrer"
					FinSi
				FinSi
			FinSi
		FinSi
SiNo
	Escribir "Mal, este juego no es para ti. El numero era: ", clave[1], clave[2], clave[3], clave[4]
FinSi

FinAlgoritmo
