Algoritmo DiceParty
	Definir jugador, cpu, nivel Como Entero
	jugador <- 0 
	cpu <- 0
	nivel <- 1
	
	Escribir "Bienvenido a Dice Party"
	Escribir "En este juego competiras contra la cpu, atraves de niveles para ver quien es el mas rapido en subir por ellos"
	Escribir "Cada nivel contiene 10 puestos. Debes tirar el dado y avanzar segun el numero que te toque"
	Escribir "En el camino podras encontrar trampas y ayudas que cambiaran tu juego"
	Escribir "El primero que pase cada nivel tendra un bonus de 1 tirada mas"
	
	Escribir "�Estas preparado para jugar? (si/no)"
	Leer respuesta
	respuesta <- Minusculas(respuesta)
	Si respuesta = "si" Entonces
		Escribir "Que comeinze tu travesia"
	SiNo
		Escribir "�Sentiste miedo?, me da igual, que comience el juego"
	FinSi
	
	Escribir ""
	Escribir "==== Nivel 1: Desierto===="
	Escribir "Tu camino comienza en el arido desierto debes avanzar si quieres sobrevivir"
	Escribir "La cpu ya inicia la carrera, asi que date prisa"
	Escribir "BUENA SUERTE"
	Escribir ""
	
	//NIvel 1 = Desierto//
	
	Mientras jugador < 15 y cpu < 15 Hacer
		dado <- Azar(6)
		cpu <- cpu + dado
		Escribir "Cpu tiro ", dado, " y queda en el puesto ", cpu
		Segun cpu Hacer
			3:
				Escribir "CPU encontr� sombra refrescante, avanza 2 puestos."
				cpu <- cpu + 2
			7:
				Escribir "CPU encontr� un oasis secreto, avanza 3 puestos."
				cpu <- cpu + 3
			12:
				Escribir "CPU encontr� un camello amistoso, avanza 1 puesto."
				cpu <- cpu + 1
			14:
				Escribir "CPU encontr� un pergamino m�gico, tira el dado otra vez."
				dado <- Azar(6)
				Escribir "CPU tir� el dado otra vez y obtuvo ", dado
				cpu <- cpu + dado
			5:
				Escribir "CPU cay� en arena movediza, retrocede 2 puestos."
				cpu <- cpu - 2
			9:
				Escribir "CPU fue picada por un escorpi�n, retrocede 2 puestos."
				cpu <- cpu - 2
			11:
				Escribir "CPU se quem� con el sol abrasador, retrocede 1 puesto."
				cpu <- cpu - 1
			13:
				Escribir "CPU tropez� con una roca gigante, retrocede 1 puesto."
				cpu <- cpu - 1
FinSegun
Si cpu >= 15 Entonces
	Escribir "�La CPU lleg� al final del nivel! Gana una tirada bonus."
	dado <- Azar(6)
	cpu <- cpu + dado
	Escribir "CPU sac� ", dado, " en su tirada bonus final."
	FinSi
			Escribir  ""
			Escribir "Cpu quedo en el puesto: ", cpu
			Escribir ""
			Escribir "Es tu turno. Escribe - tirar - para lanzar el dado"
			Leer respuesta
			respuesta <- Minusculas(respuesta)
			Si respuesta = "tirar" Entonces
				dado <- Azar(6)
				jugador <- jugador + dado
				Escribir "Jugador tir� ", dado, " y est� en el puesto ", jugador
			FinSi
			Segun jugador Hacer
                3:
                    Escribir "Encontraste sombra refrescante. Avanzas 2 puestos."
                    jugador <- jugador + 2
                7:
                    Escribir "Encontraste un oasis secreto. Avanzas 3 puestos."
                    jugador <- jugador + 3
                12:
                    Escribir "Encontraste un camello amistoso. Avanzas 1 puesto."
                    jugador <- jugador + 1
                14:
                    Escribir "Encontraste un pergamino m�gico. Tiras el dado otra vez."
                    dado <- Azar(6)
                    Escribir "Sacaste ", dado, " en la tirada extra."
                    jugador <- jugador + dado
                5:
                    Escribir "Ca�ste en arena movediza. Retrocedes 2 puestos."
                    jugador <- jugador - 2
                9:
                    Escribir "Te pic� un escorpi�n. Retrocedes 2 puestos."
                    jugador <- jugador - 2
                11:
                    Escribir "El sol te quem� demasiado. Retrocedes 1 puesto."
                    jugador <- jugador - 1
                13:
                    Escribir "Tropezaste con una roca gigante. Retrocedes 1 puesto."
                    jugador <- jugador - 1
            FinSegun
			Si jugador >= 15 Entonces
                Escribir "�Llegaste al final del nivel! Bonus: una tirada m�s."
                dado <- Azar(6)
                jugador <- jugador + dado
                Escribir "Sacaste ", dado, " en tu tirada bonus final."
            FinSi
			Escribir  ""
			Escribir "Jugador quedo en el puesto: ", jugador
            Escribir ""
				Si jugador >= 15 Entonces
					Escribir "�Ganaste el Nivel 1: Desierto!"
					Si cpu >= 15 Entonces
					Escribir "La CPU gan� el Nivel 1... el desierto no fue tu amigo hoy."
				FinSi
			FinSi
	FinMientras
	
	//Fin NIvel 1 = Desierto//
	
	//NIvel 2 = Selva//
	
	Si jugador >= 15 o cpu >= 15 Entonces
		Escribir ""
		Escribir "==== Nivel 2: Selva===="
		Escribir "Hayas perdido o ganado saliste del desierto, ahora entras a la selva "
		Escribir "No se si esperaste o la Cpu te espero pero sigue adelante es un nivel mas cerca de la meta"
		Escribir "BUENA SUERTE"
		Escribir ""
		
		Mientras jugador < 25 y cpu < 25 Hacer
			Escribir ""
            Escribir "Turno de la CPU..."
            Esperar 1 Segundos
            dado <- Azar(6)
            cpu <- cpu + dado
			Escribir "Cpu tiro ", dado, " y queda en el puesto ", cpu
			Segun cpu Hacer 
				17:
                    Escribir "CPU comi� frutas energ�ticas, avanza 2 puestos."
                    cpu <- cpu + 2
                20:
                    Escribir "CPU usa una liana, avanza 3 puestos."
                    cpu <- cpu + 3
                23:
                    Escribir "CPU encuentra un atajo, avanza 1 puesto."
                    cpu <- cpu + 1
                24:
                    Escribir "CPU cae al r�o y avanza con la corriente. Tira otra vez."
                    dado <- Azar(6)
                    Escribir "CPU sac� ", dado, " en la tirada extra."
                    cpu <- cpu + dado
                18:
                    Escribir "CPU es mordida por serpientes. Retrocede 2 puestos."
                    cpu <- cpu - 2
                19:
                    Escribir "CPU queda atascada en el pantano. Retrocede 3 puestos."
                    cpu <- cpu - 3
                21:
                    Escribir "CPU atacada por abejas. Retrocede 1 puesto."
                    cpu <- cpu - 1
                22:
                    Escribir "CPU tropieza con ra�ces. Retrocede 2 puestos."
                    cpu <- cpu - 2
            FinSegun	
			Si cpu >= 25 Entonces
                Escribir "�La CPU lleg� al final de la selva! Gana una tirada bonus."
                dado <- Azar(6)
                cpu <- cpu + dado
                Escribir "CPU sac� ", dado, " en su tirada bonus final."
			FinSi
			Escribir ""
			Escribir "Es tu turno. Escribe - tirar - para lanzar el dado"
			Leer respuesta
			respuesta <- Minusculas(respuesta)
			Si respuesta = "tirar" Entonces
				dado <- Azar(6)
				jugador <- jugador + dado
				Escribir "Jugador tir� ", dado, " y est� en el puesto ", jugador
			FinSi
			Segun jugador Hacer
                17:
                    Escribir "Encontraste frutas energ�ticas. Avanzas 2 puestos."
                    jugador <- jugador + 2
                20:
                    Escribir "Un mono te lanza una liana, avanzas 3 puestos."
                    jugador <- jugador + 3
                23:
                    Escribir "Encontraste un atajo entre los �rboles. Avanzas 1 puesto."
                    jugador <- jugador + 1
                24:
                    Escribir "Corriente del r�o te empuja, tiras el dado otra vez."
                    dado <- Azar(6)
                    Escribir "Sacaste ", dado, " en la tirada extra."
                    jugador <- jugador + dado
                18:
                    Escribir "Te atacan serpientes venenosas. Retrocedes 2 puestos."
                    jugador <- jugador - 2
                19:
                    Escribir "Te atascas en un pantano. Retrocedes 3 puestos."
                    jugador <- jugador - 3
                21:
                    Escribir "Abejas furiosas te persiguen. Retrocedes 1 puesto."
                    jugador <- jugador - 1
                22:
                    Escribir "Ra�ces te hacen tropezar. Retrocedes 2 puestos."
                    jugador <- jugador - 2
            FinSegun
			
            Si jugador >= 25 Entonces
                Escribir "�Llegaste al final de la selva! Bonus: una tirada m�s."
                dado <- Azar(6)
                jugador <- jugador + dado
                Escribir "Sacaste ", dado, " en tu tirada bonus final."
            FinSi
		FinMientras
		Escribir ""
		Si jugador >= 25 Y cpu >= 25 Entonces
			Escribir "�Empate! Ambos cruzaron la selva a la vez."
		Sino
			Si jugador >= 25 Entonces
				Escribir "�Ganaste el Nivel 2: Selva!"
			Sino
				Escribir "La CPU domin� la selva esta vez..."
			FinSi
	    FinSi
	FinSi
	
	// NIvel 2 = Selva//
	
	// NIvel 3 = Monta�a//
	Si jugador >= 25 o cpu >= 25 Entonces
		Escribir ""
		Escribir "==== Nivel 3: Monta�a===="
		Escribir "Saliste de la peligrosa selda y el fin del camino hacia la victoria esta en la cima de la monta�a "
		Escribir "La meta esta a unos cuantos turnos no permitas que te arrebaten el triunfo"
		Escribir "BUENA SUERTE"
		Escribir ""
		
		Mientras jugador < 50 y cpu < 50 Hacer
			Escribir ""
            Escribir "Turno de la CPU..."
            Esperar 1 Segundos
            dado <- Azar(6)
            cpu <- cpu + dado
			Escribir "Cpu tiro ", dado, " y queda en el puesto ", cpu
			Segun cpu Hacer
				28:
					Escribir "CPU encontr� una cuerda resistente, avanza 3 puestos."
					cpu <- cpu + 3
				31:
					Escribir "CPU desliza por la nieve dura, avanza 2 puestos."
					cpu <- cpu + 2
				35:
					Escribir "CPU encuentra un atajo en la cueva, avanza 3 puestos."
					cpu <- cpu + 3
				40:
					Escribir "CPU es guiada por un �guila gigante, avanza 2 puestos."
					cpu <- cpu + 2
				45:
					Escribir "CPU bebe agua de manantial y tira otra vez."
					dado <- Azar(6)
					Escribir "CPU sac� ", dado, " en la tirada extra."
					cpu <- cpu + dado
				29:
					Escribir "CPU sufri� ca�da de rocas, retrocede 3 puestos."
					cpu <- cpu - 3
				32:
					Escribir "CPU tropez� con hielo resbaladizo, retrocede 2 puestos."
					cpu <- cpu - 2
				34:
					Escribir "Avalancha leve afecta a la CPU, retrocede 3 puestos."
					cpu <- cpu - 3
				37:
					Escribir "Nieve profunda ralentiza a la CPU, retrocede 2 puestos."
					cpu <- cpu - 2
				41:
					Escribir "Ventisca golpea a la CPU, retrocede 3 puestos."
					cpu <- cpu - 3
				46:
					Escribir "CPU cae en una grieta oculta, retrocede 4 puestos."
					cpu <- cpu - 4
				48:
					Escribir "CPU pierde el bast�n de escalada, retrocede 2 puestos."
					cpu <- cpu - 2
			FinSegun	
			Si cpu >= 50 Entonces
                Escribir "�La CPU lleg� al final de la Monta�a! Es la vencedora."
			FinSi
			Escribir ""
			Escribir "Es tu turno. Escribe - tirar - para lanzar el dado"
			Leer respuesta
			respuesta <- Minusculas(respuesta)
			Si respuesta = "tirar" Entonces
				dado <- Azar(6)
				jugador <- jugador + dado
				Escribir "Jugador tir� ", dado, " y est� en el puesto ", jugador
			FinSi
			Segun jugador Hacer
				28:
					Escribir "Encontraste una cuerda resistente, avanzas 3 puestos."
					jugador <- jugador + 3
				31:
					Escribir "Deslizaste por la nieve dura, avanzas 2 puestos."
					jugador <- jugador + 2
				35:
					Escribir "Atajo en la cueva, avanzas 3 puestos."
					jugador <- jugador + 3
				40:
					Escribir "Un �guila gigante te gu�a, avanzas 2 puestos."
					jugador <- jugador + 2
				45:
					Escribir "Bebiste agua de manantial, tiras otra vez."
					dado <- Azar(6)
					Escribir "Sacaste ", dado, " en la tirada extra."
					jugador <- jugador + dado
				29:
					Escribir "Ca�ste en ca�da de rocas, retrocedes 3 puestos."
					jugador <- jugador - 3
				32:
					Escribir "Tropezaste con hielo resbaladizo, retrocedes 2 puestos."
					jugador <- jugador - 2
				34:
					Escribir "Avalancha leve, retrocedes 3 puestos."
					jugador <- jugador - 3
				37:
					Escribir "Nieve profunda te ralentiza, retrocedes 2 puestos."
					jugador <- jugador - 2
				41:
					Escribir "Ventisca te golpea, retrocedes 3 puestos."
					jugador <- jugador - 3
				46:
					Escribir "Ca�ste en una grieta oculta, retrocedes 4 puestos."
					jugador <- jugador - 4
				48:
					Escribir "Perdiste tu bast�n de escalada, retrocedes 2 puestos."
					jugador <- jugador - 2
			FinSegun
			
            Si jugador >= 50 Entonces
                Escribir "�Llegaste al final de la Monta�a! Eres un campeon."
            FinSi
		FinMientras
		Escribir ""
		Si jugador >= 50 Y cpu >= 50 Entonces
			Escribir "�Empate! Ambos llegaron a la meta a la vez."
		Sino
			Si jugador >= 50 Entonces
				Escribir "�Ganaste el Nivel 3: Monta�a!"
				Si  cpu >= 50 Entonces
				Escribir "La CPU conquisto la cima esta vez y para siempre..."
			FinSi
	    FinSi
	FinSi
FinSi

			
			
			
			
			
		
	
	
	
		FinAlgoritmo
		
